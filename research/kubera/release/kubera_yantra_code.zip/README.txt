The Kubera Yantra: Textual Lineage, Combinatorial Structure, and an Emic Reconstruction of a 3x3 Wealth Cosmogram
Sangaraju Vikram Varma (ORCID 0009-0000-5368-503X), Bangalore, India. Preprint, 2026.

code/    Python 3 scripts (NumPy, Matplotlib). Run: bash code/run_all.sh  -> code/results.txt
paper/   LaTeX source (IEEEtran). Build with lualatex: lualatex, bibtex, lualatex, lualatex.
Licence: CC BY 4.0.
